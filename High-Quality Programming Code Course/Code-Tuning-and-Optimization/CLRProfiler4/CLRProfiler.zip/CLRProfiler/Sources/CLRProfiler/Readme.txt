CLRProfiler project
===================

This is the project that builds the GUI executable that is the CLRProfiler application. This runs out of process with respect
to the application being debugged.

It analyzes a log file that is produced by an unmanaged dll that is loaded by the application being profiled - see ProfilerOBJ project.

