These demos show how to use CLRProfilerControl to control profiling from the application
being profiled.

The demos are intended to be run under CLRProfiler.

Build the CLRProfiler solution first.
