CLRProfiler solution
====================

This solution consists of 3 projects:

- CLRProfiler builds the GUI executable that is the profiler
- ProfilerOBJ builds a helper dll that is loaded into
  the application being profiled
- CLRProfilerControl is an optional component that allows
  the application being profiled to control the profiling.
