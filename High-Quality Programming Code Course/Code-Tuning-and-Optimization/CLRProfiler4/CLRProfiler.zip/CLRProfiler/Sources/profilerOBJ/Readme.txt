ProfilerOBJ project
===================

This project builds an unmanaged dll that is loaded into the process of the application
being profiled.

It is a COM component that receives profiling notifications from the CLR and responds
to them by writing into a log file.
